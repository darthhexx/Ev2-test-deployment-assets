#!/bin/bash

set -e

echo "This is the $(basename $0) file"

export AZURE_EV2="Use MSI"
export MDM_NAMESPACE="UpdateOCPVersions"
export PYTHONIOENCODING=UTF-8
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
export LOCATION=$RP_LOCATION

azureLogin() {
    echo "azureLogin ==============================================================="
    local retries=5
    local waitDuration=5

    echo "Logging into Azure to deploy"

    while [ "$retries" -gt 0 ]; do
        if az login --identity
        then
            echo "az login successful"
            break
        else
            ((retries--))
            echo "az login failed. Will retry $retries time(s) in $waitDuration sec..."
            sleep "$waitDuration"
        fi
    done

    if [ "$retries" -eq 0 ]
    then
        echo "az login failed 5 times. Exiting script..."
        exit 2
    else
        echo "az login complete"
    fi
    echo "=========================================================================="
}

echo "working path: $(pwd)"
echo "Directory contents"
ls

azureLogin

echo "running aro update-versions"

chmod +x aro
aro update-versions
